const pagesRouter = require("express").Router();
const {sendIndex, sendDashboard} = require("../controllers/auth");
const { checkAuth, checkCookiesTOKEN } = require("../middlewares/auth");

pagesRouter.get("/", sendIndex);
pagesRouter.get("/admin/**", checkCookiesTOKEN, checkAuth, sendDashboard);
module.exports = pagesRouter