const getTOKENFromCookie = () => {
  const cookie = document.cookie
    .split(";")
    .find(cookie => cookie.trim().startsWith("token="));
  return cookie ? cookie.split("=")[1] : null;
};

const getData = async url => {
  try {
    const response = await fetch(url);
    const data = await response.json();
    return data;
  } catch (err) {
    console.error(err);
  }
};

const postData = async (url, data) => {
  const token = getTOKENFromCookie();
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: token && `Bearer ${token}`
      },
      body: JSON.stringify(data)
    });
    if (response.status !== 200) {
      throw new Error((await response.json()).message);
    }
    return response;
  } catch (err) {
    return err;
  }
};

const putData = async (url, data) => {
  const token = getTOKENFromCookie();
  try {
    const response = await fetch(url, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: token && `Bearer ${token}`
      },
      body: JSON.stringify(data)
    });
    if (response.status !== 200) {
      throw new Error((await response.json()).message);
    }
    return response;
  } catch (err) {
    return err;
  }
};

const deleteData = async url => {
  const token = getTOKENFromCookie();
  try {
    const response = await fetch(url, {
      headers: {
        "Content-Type": "application/json",
        Authorization: token && `Bearer ${token}`
      },
      method: "DELETE"
    });
    return response;
  } catch (err) {
    console.error(err);
  }
};

export { getData, postData, putData, deleteData };
