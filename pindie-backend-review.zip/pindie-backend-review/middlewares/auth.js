const token = require("jsonwebtoken")

const checkAuth = (req, res, next) => {
    const { authorization } = req.headers;
    if (!authorization || !authorization.startsWith("Bearer ")) {
      return res.status(401).send({ message: "Необходима авторизация" });
    }
    const token = authorization.replace("Bearer ", "");
    try {
      req.user = token.verify(token, "some-secret-key");
    } catch (err) {
      return res.status(401).send({ message: "Необходима авторизацио" });
    }
    next();
  };
  
const checkCookiesTOKEN = (req, res, next) => {
    if (!req.cookies.token) {
        return res.redirect("/")
    }
    req.headers.authorization = `Bearer ${req.cookies.token}`;
    next();
};
module.exports = {
    checkAuth,
    checkCookiesTOKEN,
}