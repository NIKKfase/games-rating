
const {getData} = require('./api-utils');
const endpoints = require('./config');

module.exports = {
    endpoints,
    getData
};